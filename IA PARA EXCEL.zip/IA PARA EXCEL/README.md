# MCP Microsoft Excel

Servidor **MCP** (Model Context Protocol) para controlar **Microsoft Excel** en macOS desde un asistente de IA como opencode. Permite listar libros abiertos, leer valores y formulas, crear o abrir libros, escribir rangos y recalcular formulas. Esta pensado para acompanar ejercicios de Contabilidad: el chat puede revisar la planilla, explicar lo que falta y escribir los resultados.

La via de integracion elegida es **AppleScript / JXA mediante `osascript`**, porque Excel para macOS expone un diccionario de scripting completo. No se usa automatizacion de interfaz ni un puente HTTP. Los detalles de la investigacion estan en [`INVESTIGACION.md`](INVESTIGACION.md).

## Que hace

- Descubre que libros y hojas tienes abiertos en Excel.
- Lee valores y formulas de cualquier rango A1.
- Crea libros nuevos y los guarda como `.xlsx`.
- Abre archivos de Excel existentes.
- Escribe valores o formulas en un rango (con confirmacion explicita).
- Recalcula las formulas de un libro para actualizar los resultados.

## Herramientas

| Nombre | Que hace | Modifica datos |
|---|---|---|
| `listar_libros_abiertos` | Lista los libros abiertos, su ruta y sus hojas. Sirve para obtener los nombres exactos antes de leer o escribir. | No |
| `leer_rango` | Lee los valores visibles de un rango A1 de un libro y hoja. | No |
| `leer_formulas` | Lee las formulas de un rango A1. Util para entender plantillas contables y revisar calculos. | No |
| `crear_libro` | Crea un libro nuevo, opcionalmente lo guarda como `.xlsx` y nombra la primera hoja. No sobrescribe archivos existentes. | Si (crea un libro nuevo) |
| `abrir_libro` | Abre un archivo `.xlsx`, `.xlsm`, `.xls` o `.csv` que exista en el computador. | No modifica el contenido, solo abre el archivo |
| `escribir_rango` | Escribe una matriz de valores o formulas en un rango. Sobrescribe las celdas indicadas y exige `confirmar: true`. | Si (sobrescribe celdas) |
| `recalcular_libro` | Recalcula las formulas de todas las hojas de un libro abierto. | No cambia los valores introducidos; actualiza resultados de formulas |

### Notas de uso

- Los nombres de libro y hoja deben ser **exactos**. Si no los conoces, usa primero `listar_libros_abiertos`.
- Los rangos usan notacion A1, por ejemplo `A1` o `A1:L61`. No incluyas el nombre de la hoja dentro del rango.
- Para escribir formulas, cada texto debe empezar con `=`, por ejemplo `=SUMA(B2:B10)`.
- `escribir_rango` puede reemplazar datos: el asistente debe pedirte confirmacion antes de invocarla con `confirmar: true`.
- Los rangos de lectura y escritura estan limitados a 5.000 celdas por llamada para evitar respuestas gigantes o escrituras accidentales.

## Ejemplos de frases para pedirselas a la IA

1. **Revisar un ejercicio existente:**  
   "Abre `/Users/mi_usuario/Desktop/Libro_Contable.xlsx`, revisa la hoja `Libro Diario` y explicame que datos hay y que se pide resolver."

2. **Armar una planilla contable nueva:**  
   "Crea un libro en el Escritorio llamado `Ejercicio_Contabilidad.xlsx` con una hoja `Libro Diario`, escribe los encabezados Fecha, Cuenta, Debe y Haber, y deja el formato listo para trabajar."

3. **Escribir y verificar resultados:**  
   "En el libro `Ejercicio_Contabilidad.xlsx`, hoja `Libro Diario`, escribe los asientos que te dicte en A2:D10, agrega formulas de suma en la fila de totales y recalcula el libro."

## Requisitos

- **macOS** (probado en macOS 26.4).
- **Microsoft Excel** instalado en `/Applications/Microsoft Excel.app` (probado con Excel 16.114.1).
- **Node.js 18 o superior**.
- **opencode** u otro cliente MCP compatible con servidores stdio.

## Instalacion y uso

```bash
npm install
npm run build
npm test
```

Para probar visualmente las herramientas:

```bash
npm run inspect
```

Para abrir Excel y opencode juntos con el MCP ya registrado:

```bash
./Abrir-microsoft-excel.command
```

Si macOS bloquea la ejecucion del lanzador, ejecutalo con:

```bash
bash Abrir-microsoft-excel.command
```

Tambien puedes registrar el MCP manualmente en el `opencode.json` de este proyecto:

```bash
npm run configurar -- --nombre=microsoft-excel
```

El comando apunta a `dist/index.js`, por lo que **debes compilar antes** con `npm run build`.

## Permisos del sistema

La primera vez que el MCP intente controlar Excel, macOS puede mostrar un aviso de **Automatizacion**. Debes permitir que el programa que ejecuta `osascript` (opencode, Terminal o Node) controle **Microsoft Excel**.

Puedes revisarlo o cambiarlo en:

**Ajustes del Sistema → Privacidad y seguridad → Automatizacion**

Si lo rechazaste por error, borra el permiso y vuelve a intentarlo. No se necesita permiso de Accesibilidad ni de grabacion de pantalla, porque no se automatiza la interfaz visual.

## Arranque de Excel

Microsoft Excel **no necesita parametros especiales** para ser controlado: su diccionario AppleScript esta siempre disponible cuando la app esta instalada y abierta. Por eso este proyecto **no** incluye `scripts/preparar-app.mjs` ni un puente local.

- Las herramientas de lectura y escritura requieren que Excel este abierto.
- `abrir_libro` y `crear_libro` pueden abrir Excel si estaba cerrado.
- Si Excel muestra un dialogo modal (por ejemplo, "guardar cambios" o un aviso de proteccion), las herramientas pueden esperar hasta el tiempo limite y fallar. Cierra o responde el dialogo y vuelve a intentarlo.

## Limitaciones conocidas

- **Solo macOS.** No se implemento soporte para Windows ni Linux.
- **Operaciones de escritura no probadas de punta a punta.** Durante la verificacion se probaron contra Excel real las herramientas de solo lectura (`listar_libros_abiertos`, `leer_rango`, `leer_formulas`) y el manejo de errores. Las herramientas que crean, abren o modifican datos no se ejecutaron sobre datos reales para no alterar los archivos del usuario. Si alguna falla, el mensaje de error indica el libro, la hoja y el rango afectados.
- **Sin formato avanzado.** No se controlan colores, bordes, anchos de columna, graficos, tablas dinamicas, macros ni validaciones. Solo valores, formulas y calculos.
- **Valores, no texto formateado.** `leer_rango` devuelve el valor de la celda. Una fecha puede aparecer como numero de serie y un numero puede no incluir separadores de miles; el formato visible depende de Excel.
- **Rangos maximos de 5.000 celdas** por lectura o escritura. Para planillas grandes, divide el trabajo en varios rangos.
- **Nombres exactos.** Si un libro esta sin guardar, su "ruta" puede ser solo el nombre (por ejemplo `Libro1`).
- **Un solo Excel.** El MCP trabaja con la instancia de Excel que este abierta en el usuario actual. Si hay dialogos o instancias inesperadas, puede ser necesario cerrar y volver a abrir Excel.
- **CSV.** Abrir un `.csv` puede mostrar el asistente de importacion de Excel segun la configuracion del equipo; eso puede bloquear la respuesta hasta que lo cierres.

## Estructura del codigo

- `src/tools/microsoft-excel.ts` — define las 7 herramientas MCP y sus validaciones.
- `src/lib/excel.ts` — puente seguro con `osascript` (JXA/AppleScript), sin concatenar texto del modelo.
- `INVESTIGACION.md` — vias evaluadas y justificacion de la decision.
- `scripts/smoke-test.mjs` — prueba de humo generica (`npm test`).
