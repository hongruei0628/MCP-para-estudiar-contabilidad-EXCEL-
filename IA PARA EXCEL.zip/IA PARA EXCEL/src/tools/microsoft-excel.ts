/**
 * Herramientas MCP para controlar Microsoft Excel en macOS.
 *
 * Via de integracion: JXA/AppleScript mediante osascript (ver INVESTIGACION.md).
 * Los valores del modelo se pasan como argumentos, nunca concatenados en el script.
 */
import { existsSync, statSync } from "node:fs";
import path from "node:path";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import {
  abrirLibro,
  crearLibro,
  dimensionesRango,
  escribirRango,
  esRangoA1,
  leerFormulas,
  leerRango,
  listarLibros,
  normalizarRango,
  recalcularLibro,
} from "../lib/excel.js";
import { error, json, texto } from "../lib/respuestas.js";

const MAX_CELDAS = 5_000;
const MAX_CARACTERES_ESCRITURA = 200_000;

const libroSchema = z
  .string()
  .trim()
  .min(1)
  .max(255)
  .describe(
    "Nombre exacto del libro abierto, por ejemplo 'Libro1' o 'Guia_Certamen_2_Para_Resolver.xlsx'.",
  );

const hojaSchema = z
  .string()
  .trim()
  .min(1)
  .max(255)
  .describe("Nombre exacto de la hoja, por ejemplo '1 Existencias' o 'Hoja1'.");

const rangoSchema = z
  .string()
  .trim()
  .min(1)
  .max(50)
  .describe(
    "Rango en notacion A1, por ejemplo 'A1' o 'A1:L61'. No incluyas el nombre de la hoja.",
  )
  .refine((valor) => esRangoA1(valor), {
    message: "Rango no valido. Usa una direccion A1 como 'A1' o 'A1:L61'.",
  });

const celdaSchema = z.union([z.string(), z.number(), z.boolean(), z.null()]);

const matrizSchema = z
  .array(z.array(celdaSchema).min(1))
  .min(1)
  .describe(
    "Matriz de filas y columnas con los valores o formulas a escribir. Ejemplo para A1:B2: [[\"Cuenta\",\"Saldo\"],[1101,150000]].",
  );

function validarMatriz(valores: (string | number | boolean | null)[][]): string | null {
  if (valores.length === 0) return "La matriz de valores no puede estar vacia.";

  const columnas = valores[0]?.length ?? 0;
  if (columnas === 0) return "Cada fila debe tener al menos una celda.";

  for (let i = 1; i < valores.length; i++) {
    if (valores[i].length !== columnas) {
      return `La fila ${i + 1} tiene ${valores[i].length} columnas, pero la primera tiene ${columnas}. Todas las filas deben tener el mismo largo.`;
    }
  }

  return null;
}

function rutaAbsoluta(valor: string | undefined): string | null {
  if (!valor) return null;
  const ruta = valor.trim();
  return path.isAbsolute(ruta) ? ruta : null;
}

export function register(server: McpServer): void {
  server.registerTool(
    "listar_libros_abiertos",
    {
      title: "Listar libros abiertos",
      description:
        "Lista los libros de Microsoft Excel que estan abiertos, con su ruta y los nombres de sus hojas. Usala primero para descubrir los nombres exactos de libros y hojas antes de leer o escribir.",
      inputSchema: {},
      annotations: { readOnlyHint: true },
    },
    async () => {
      const resultado = await listarLibros();
      if (!resultado.ok) return error(resultado.error);

      if (resultado.datos.total === 0) {
        return texto(
          "No hay libros abiertos en Excel. Abre un archivo con abrir_libro o crea uno nuevo con crear_libro.",
        );
      }

      return json(resultado.datos);
    },
  );

  server.registerTool(
    "leer_rango",
    {
      title: "Leer valores de un rango",
      description:
        "Lee los valores visibles de un rango de celdas de un libro y hoja abiertos. Usala para revisar datos contables, saldos, inventarios o verificar resultados. No modifica nada.",
      inputSchema: {
        libro: libroSchema,
        hoja: hojaSchema,
        rango: rangoSchema,
      },
      annotations: { readOnlyHint: true },
    },
    async ({ libro, hoja, rango }) => {
      const rangoNormalizado = normalizarRango(rango);

      let dimensiones: { filas: number; columnas: number };
      try {
        dimensiones = dimensionesRango(rangoNormalizado);
      } catch (e) {
        return error((e as Error).message);
      }

      const celdas = dimensiones.filas * dimensiones.columnas;
      if (celdas > MAX_CELDAS) {
        return error(
          `El rango ${rangoNormalizado} tiene ${celdas} celdas y el maximo es ${MAX_CELDAS}. Pide un rango mas pequeno.`,
        );
      }

      const resultado = await leerRango(libro, hoja, rangoNormalizado);
      if (!resultado.ok) return error(resultado.error);
      return json(resultado.datos);
    },
  );

  server.registerTool(
    "leer_formulas",
    {
      title: "Leer formulas de un rango",
      description:
        "Lee las formulas de un rango de celdas de un libro y hoja abiertos. Usala para entender como esta armada una plantilla contable o para revisar calculos antes de modificarlos. No modifica nada.",
      inputSchema: {
        libro: libroSchema,
        hoja: hojaSchema,
        rango: rangoSchema,
      },
      annotations: { readOnlyHint: true },
    },
    async ({ libro, hoja, rango }) => {
      const rangoNormalizado = normalizarRango(rango);

      let dimensiones: { filas: number; columnas: number };
      try {
        dimensiones = dimensionesRango(rangoNormalizado);
      } catch (e) {
        return error((e as Error).message);
      }

      const celdas = dimensiones.filas * dimensiones.columnas;
      if (celdas > MAX_CELDAS) {
        return error(
          `El rango ${rangoNormalizado} tiene ${celdas} celdas y el maximo es ${MAX_CELDAS}. Pide un rango mas pequeno.`,
        );
      }

      const resultado = await leerFormulas(libro, hoja, rangoNormalizado);
      if (!resultado.ok) return error(resultado.error);
      return json(resultado.datos);
    },
  );

  server.registerTool(
    "crear_libro",
    {
      title: "Crear libro de Excel",
      description:
        "Crea un libro nuevo en Microsoft Excel y, si se indica, lo guarda como archivo .xlsx. Usala para empezar un ejercicio contable desde cero. No sobrescribe archivos existentes.",
      inputSchema: {
        guardar_como: z
          .string()
          .trim()
          .optional()
          .describe(
            "Ruta absoluta del archivo .xlsx a crear, por ejemplo '/Users/tu_usuario/Desktop/Ejercicio.xlsx'. Si se omite, el libro queda sin guardar.",
          ),
        nombre_hoja: z
          .string()
          .trim()
          .min(1)
          .max(31)
          .optional()
          .describe(
            "Nombre de la primera hoja (maximo 31 caracteres, sin : \\ / ? * [ ]). Si se omite, Excel usa el nombre por defecto.",
          ),
      },
      annotations: { readOnlyHint: false, destructiveHint: false },
    },
    async ({ guardar_como, nombre_hoja }) => {
      const ruta = rutaAbsoluta(guardar_como);
      if (guardar_como && !ruta) {
        return error("La ruta de guardado debe ser absoluta, por ejemplo '/Users/tu_usuario/Desktop/Ejercicio.xlsx'.");
      }

      if (ruta) {
        if (path.extname(ruta).toLowerCase() !== ".xlsx") {
          return error("El archivo debe tener extension .xlsx.");
        }
        if (existsSync(ruta)) {
          return error(
            `Ya existe un archivo en ${ruta}. Para no sobrescribirlo, elige otro nombre o elimina el archivo manualmente.`,
          );
        }
        if (!existsSync(path.dirname(ruta))) {
          return error(`La carpeta ${path.dirname(ruta)} no existe. Crea la carpeta o usa otra ruta.`);
        }
      }

      if (nombre_hoja && /[:\\/?*[\]]/.test(nombre_hoja)) {
        return error("El nombre de la hoja no puede contener : \\ / ? * [ ].");
      }

      const resultado = await crearLibro(ruta ?? "", nombre_hoja ?? "");
      if (!resultado.ok) return error(resultado.error);

      const hoja = resultado.datos.hojas[0] ?? "(sin hojas)";
      return texto(
        `Libro creado: ${resultado.datos.nombre}\nRuta: ${resultado.datos.ruta}\nHoja inicial: ${hoja}`,
      );
    },
  );

  server.registerTool(
    "abrir_libro",
    {
      title: "Abrir libro de Excel",
      description:
        "Abre en Microsoft Excel un archivo .xlsx, .xlsm, .xls o .csv que exista en el computador. Usala cuando el usuario indique una ruta de archivo que aun no esta abierto.",
      inputSchema: {
        ruta: z
          .string()
          .trim()
          .min(1)
          .describe(
            "Ruta absoluta del archivo a abrir, por ejemplo '/Users/tu_usuario/Desktop/Guia.xlsx'.",
          ),
      },
      annotations: { readOnlyHint: false, destructiveHint: false },
    },
    async ({ ruta }) => {
      const rutaNormalizada = path.normalize(ruta);
      if (!path.isAbsolute(rutaNormalizada)) {
        return error("La ruta debe ser absoluta, por ejemplo '/Users/tu_usuario/Desktop/Guia.xlsx'.");
      }

      const extensionesPermitidas = [".xlsx", ".xlsm", ".xls", ".csv"];
      if (!extensionesPermitidas.includes(path.extname(rutaNormalizada).toLowerCase())) {
        return error(`Extension no soportada. Usa una de: ${extensionesPermitidas.join(", ")}.`);
      }

      if (!existsSync(rutaNormalizada)) {
        return error(`No existe el archivo ${rutaNormalizada}. Revisa la ruta.`);
      }

      if (!statSync(rutaNormalizada).isFile()) {
        return error(`La ruta ${rutaNormalizada} no apunta a un archivo.`);
      }

      const resultado = await abrirLibro(rutaNormalizada);
      if (!resultado.ok) return error(resultado.error);
      return json({ abierto: true, ...resultado.datos });
    },
  );

  server.registerTool(
    "escribir_rango",
    {
      title: "Escribir valores o formulas en un rango",
      description:
        "Escribe una matriz de valores o formulas en un rango de celdas. SOBRESCRIBE el contenido actual de esas celdas. Usala solo cuando el usuario haya confirmado explicitamente que quiere escribir o reemplazar datos. Para formulas, cada texto debe empezar con '='.",
      inputSchema: {
        libro: libroSchema,
        hoja: hojaSchema,
        rango: rangoSchema,
        valores: matrizSchema,
        confirmar: z
          .literal(true)
          .describe(
            "Debe ser true. Escribe true solo si el usuario confirmo explicitamente que se sobrescribiran celdas.",
          ),
      },
      annotations: { readOnlyHint: false, destructiveHint: true },
    },
    async ({ libro, hoja, rango, valores }) => {
      const rangoNormalizado = normalizarRango(rango);

      let dimensiones: { filas: number; columnas: number };
      try {
        dimensiones = dimensionesRango(rangoNormalizado);
      } catch (e) {
        return error((e as Error).message);
      }

      const problemaMatriz = validarMatriz(valores);
      if (problemaMatriz) return error(problemaMatriz);

      const filas = valores.length;
      const columnas = valores[0]?.length ?? 0;

      if (filas !== dimensiones.filas || columnas !== dimensiones.columnas) {
        return error(
          `La matriz es de ${filas} fila(s) por ${columnas} columna(s), pero el rango ${rangoNormalizado} es de ${dimensiones.filas} fila(s) por ${dimensiones.columnas} columna(s). Ajusta la matriz o el rango.`,
        );
      }

      const celdas = filas * columnas;
      if (celdas > MAX_CELDAS) {
        return error(
          `Intentas escribir ${celdas} celdas y el maximo es ${MAX_CELDAS}. Divide la escritura en varios rangos mas pequenos.`,
        );
      }

      if (JSON.stringify(valores).length > MAX_CARACTERES_ESCRITURA) {
        return error(
          "Los valores son demasiado grandes para una sola escritura. Divide el contenido en varios rangos.",
        );
      }

      const resultado = await escribirRango(libro, hoja, rangoNormalizado, valores);
      if (!resultado.ok) return error(resultado.error);

      return texto(
        `Escritas ${resultado.datos.filas * resultado.datos.columnas} celdas en ${resultado.datos.libro} / ${resultado.datos.hoja}, rango ${resultado.datos.rango}.`,
      );
    },
  );

  server.registerTool(
    "recalcular_libro",
    {
      title: "Recalcular formulas de un libro",
      description:
        "Recalcula las formulas de todas las hojas de un libro abierto. Usala despues de escribir formulas para asegurar que los resultados contables esten actualizados. No cambia los valores introducidos manualmente.",
      inputSchema: {
        libro: libroSchema,
      },
      annotations: { readOnlyHint: false, destructiveHint: false },
    },
    async ({ libro }) => {
      const resultado = await recalcularLibro(libro);
      if (!resultado.ok) return error(resultado.error);

      return texto(
        `Formulas recalculadas en ${resultado.datos.libro} (${resultado.datos.hojas} hoja(s)): ${resultado.datos.nombresHojas.join(", ")}.`,
      );
    },
  );
}
