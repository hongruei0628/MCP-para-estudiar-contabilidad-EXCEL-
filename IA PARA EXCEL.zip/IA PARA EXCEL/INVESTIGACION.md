# Investigación: controlar Microsoft Excel en macOS

Fecha: 2026-11-06

## Datos del entorno

| Dato | Valor observado |
|---|---|
| App | Microsoft Excel |
| Ruta | `/Applications/Microsoft Excel.app` |
| Versión | 16.114.1 (build 16.114.26102031) |
| macOS | 26.4 (build 25E246) |
| Scripting | `NSAppleScriptEnabled = true`, `OSAScriptingDefinition = Excel.sdef` |
| Estado durante la investigación | Excel estaba abierto con 2 libros (`Libro1` y `Libro_Contable.xlsx`) |

## Vías evaluadas (de la más robusta a la más frágil)

### 1. API HTTP / WebSocket / plugin oficial

- Revisé `Contents/Info.plist`: no hay puertos, plugins MCP ni servidor HTTP local declarado.
- El `Info.plist` sí declara esquemas de URL (`launch-excel`, `open-excel`, `ms-excel`, `excel`), pero sirven para abrir la app o un archivo, no para leer/escribir celdas.
- **Descartada** como vía de control de datos, porque no existe una API local documentada para Excel de escritorio en macOS.

### 2. CLI de la app

- `Contents/MacOS/` solo contiene el ejecutable `Microsoft Excel`.
- No hay binario de consola tipo `excel-cli` ni opciones documentadas de control por línea de comandos.
- **Descartada**.

### 3. Archivos de datos (`.xlsx`)

- Un `.xlsx` es un ZIP con XML (`xl/workbook.xml`, `xl/worksheets/sheet*.xml`, etc.).
- Se podría leer/escribir con librerías de Node, pero:
  - no refleja cambios en tiempo real en la app abierta;
  - puede corromper el archivo si Excel lo tiene abierto;
  - obliga a reimplementar fórmulas, formatos, tablas y validaciones.
- **Descartada como vía principal**. Podría ser un fallback futuro para trabajar sin Excel abierto, pero no para el objetivo de "chat al lado del Excel".

### 4. AppleScript / JXA (vía elegida)

- Excel es "scriptable": el diccionario `Excel.sdef` tiene ~9.160 líneas y expone clases como `application`, `workbook`, `worksheet`, `range`, `cell`, `formula`, etc.
- Comprobaciones de solo lectura realizadas con `osascript`:
  - `name of every workbook` → `Libro1, Libro_Contable.xlsx`
  - `full name of every workbook` → ruta real del archivo abierto
  - `name of every worksheet of workbook "..."` → hojas del libro
  - `value of range "A1:L3"` → matriz (lista de listas) con los valores
  - JXA devuelve directamente JSON, ideal para un servidor MCP.
- **Vía elegida**: JXA (`osascript -l JavaScript`) por ser más cómoda para validar JSON y pasar argumentos, manteniendo el mismo motor Apple Events que AppleScript.
- Los valores del modelo se pasan siempre como **argumentos** del script (`function run(argv)`), nunca concatenados dentro del código.

### 5. Automatización de interfaz (UI scripting)

- Sería posible con Accesibilidad, pero es frágil ante cambios de versión, idioma o disposición de ventanas.
- **Descartada** mientras exista scripting nativo.

## Decisión

Usar **JXA mediante `osascript`** como puente entre el servidor MCP y Microsoft Excel.

Motivos:

1. Es la API nativa y soportada por Excel para macOS.
2. Permite leer y escribir rangos completos en una sola operación.
3. Devuelve estructuras JSON fáciles de validar y presentar al modelo.
4. No requiere plugins, puertos ni permisos especiales más allá de Automatización de macOS.

## Consecuencias y limitaciones

- **Permiso de Automatización**: la primera vez, macOS puede pedir permiso para que el proceso que ejecuta `osascript` (opencode, Terminal, Node, etc.) controle Microsoft Excel. Se concede en *Ajustes del Sistema → Privacidad y seguridad → Automatización*.
- **Excel debe estar instalado**. Para leer/escribir datos, normalmente debe estar abierto.
- Si Excel muestra un diálogo modal o está ocupado, las órdenes pueden tardar o fallar; el MCP debe devolver un error claro.
- Los rangos muy grandes pueden tardar y generar respuestas enormes; conviene limitar filas/columnas y validar el rango.
- Los tipos de datos se convierten a texto/JSON; fechas y números pueden requerir revisión según la configuración regional.
- Las operaciones de escritura no se probaron contra datos reales durante esta investigación, siguiendo la regla de no modificar datos del usuario.

## Fuentes consultadas

- Diccionario local: `/Applications/Microsoft Excel.app/Contents/Resources/Excel.sdef`
- `Info.plist` de la app (`plutil -p`)
- MacTech, *AppleScript and Microsoft Excel*: <http://preserve.mactech.com/articles/mactech/Vol.23/23.02/2302AppleScript/index.html>
- Excel 2004 AppleScript Reference (patrones de `make new workbook`, `open workbook`, `range`): <https://applescriptlibrary.wordpress.com/wp-content/uploads/2013/11/excel-2004-applescript-reference.pdf>
- Documentación y ejemplos de JXA para Excel: <https://skills.rest/skill/automating-excel>
